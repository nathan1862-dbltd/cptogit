# OpenRouter Coding Agent

A lightweight Codex-style coding agent using OpenRouter.

## Setup

Copy the environment file:

```bash
cp .env.example .env
```

Edit `.env` and set your OpenRouter API key:

```
OPENROUTER_API_KEY=sk-or-v1-your-key-here
```

Build and start the container:

```bash
docker-compose up --build
```

## Usage

Health check:

```bash
curl http://localhost:8000/health
```

Run a coding task:

```bash
curl -X POST http://localhost:8000/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Create a hello world Python script", "max_steps": 10}'
```

## Configuration

| Variable | Default | Description |
|---|---|---|
| `OPENROUTER_API_KEY` | _(required)_ | Your OpenRouter API key |
| `OPENROUTER_MODEL` | `anthropic/claude-3.5-sonnet` | Model to use |
| `ALLOW_SHELL` | `false` | Enable shell command execution |
| `WORKSPACE` | `/workspace` | Working directory for the agent |
